module
public import A209933.Model
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace A209933

def classes : List Nat := [1, 2, 3, 4, 5, 6, 7, 8, 9, 12, 14, 15, 18, 21, 24, 28, 35, 36, 42, 45, 56, 63, 72, 84, 105, 126, 168, 252, 315, 504]

def initialWords : Nat → List Nat
  | 1 => [1111]
  | 2 => [2222]
  | 3 => [3333]
  | 4 => [4444]
  | 5 => [5555]
  | 6 => [6666]
  | 7 => [7777]
  | 8 => [8888]
  | 9 => [1199, 9999]
  | 12 => [1332, 1333]
  | 18 => [1999]
  | 24 => [2664, 2666]
  | 36 => [3999]
  | _ => []

def ds : Nat → List Nat
  | 1 => [1]
  | 2 => [1, 2]
  | 3 => [1, 3]
  | 4 => [1, 2, 4]
  | 5 => [1, 5]
  | 6 => [1, 2, 3, 6]
  | 7 => [1, 7]
  | 8 => [1, 2, 4, 8]
  | 9 => [1, 3, 9]
  | 12 => [1, 2, 3, 4, 6, 12]
  | 14 => [1, 2, 7, 14]
  | 15 => [1, 3, 5, 15]
  | 18 => [1, 2, 3, 6, 9, 18]
  | 21 => [1, 3, 7, 21]
  | 24 => [1, 2, 3, 4, 6, 8, 12, 24]
  | 28 => [1, 2, 4, 7, 14, 28]
  | 35 => [1, 5, 7, 35]
  | 36 => [1, 2, 3, 4, 6, 9, 12, 18, 36]
  | 42 => [1, 2, 3, 6, 7, 14, 21, 42]
  | 45 => [1, 3, 5, 9, 15, 45]
  | 56 => [1, 2, 4, 7, 8, 14, 28, 56]
  | 63 => [1, 3, 7, 9, 21, 63]
  | 72 => [1, 2, 3, 4, 6, 8, 9, 12, 18, 24, 36, 72]
  | 84 => [1, 2, 3, 4, 6, 7, 12, 14, 21, 28, 42, 84]
  | 105 => [1, 3, 5, 7, 15, 21, 35, 105]
  | 126 => [1, 2, 3, 6, 7, 9, 14, 18, 21, 42, 63, 126]
  | 168 => [1, 2, 3, 4, 6, 7, 8, 12, 14, 21, 24, 28, 42, 56, 84, 168]
  | 252 => [1, 2, 3, 4, 6, 7, 9, 12, 14, 18, 21, 28, 36, 42, 63, 84, 126, 252]
  | 315 => [1, 3, 5, 7, 9, 15, 21, 35, 45, 63, 105, 315]
  | 504 => [1, 2, 3, 4, 6, 7, 8, 9, 12, 14, 18, 21, 24, 28, 36, 42, 56, 63, 72, 84, 126, 168, 252, 504]
  | _ => []

def fastQ (L n : Nat) : Bool := (ds L).all (fun d => fastDigits L 4 (n/d))

set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem valid_ds : ∀ L ∈ classes, ∀ d ∈ ds L, 0 < d ∧ d ∣ L := by
  decide +kernel

theorem fastQ_of_quotients (L n : Nat) (hL : L ∈ classes) (hn : n < 10000)
    (h : Quotients L n) : fastQ L n = true := by
  have hpos : 0 < L := by
    have hv := valid_ds L hL
    simp only [classes, List.mem_cons, List.not_mem_nil, or_false] at hL
    omega
  apply List.all_eq_true.mpr
  intro d hd
  have hv := valid_ds L hL d hd
  exact (fastDigits_spec L 4 (n/d) (lt_of_le_of_lt (Nat.div_le_self _ _) hn)).2
    ((quotients_iff L n hpos).1 h d hv.2)

def coefficients : List Nat := [1,2,3,4,5,6,7,8,9,12,24]

def offsets (L : Nat) : List Nat :=
  if L = 12 then [0,1] else if L = 24 then [0,2] else [0]

def Dead (L r : Nat) : Prop :=
  (L=9 ∧ r=2) ∨ (L=18 ∧ r=1) ∨ (L=36 ∧ r=3)

instance (L r : Nat) : Decidable (Dead L r) := by unfold Dead; infer_instance

def Invariant (L n : Nat) : Prop :=
  (L ∈ coefficients ∧ ∃ t e, e ∈ offsets L ∧ n = L*repunit t+e) ∨ Dead L (n%L)

set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem classes_bounds : ∀ L ∈ classes, 0 < L ∧ L ≤ 504 := by decide +kernel

set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem offsets_bounds : ∀ L ∈ coefficients, ∀ e ∈ offsets L, e < L := by decide +kernel


end A209933
