module
public import Mathlib.Data.Nat.Digits.Lemmas
public import Mathlib.Data.Nat.Prime.Basic
public import Mathlib.Tactic.NormNum
public import Mathlib.Tactic.IntervalCases
public import Mathlib.Tactic.Ring
public import Mathlib.Tactic.FinCases

/-! Formal mathematical verification; no production sequence generator. -/
@[expose] public section
namespace A209933

def Allowed (L c : Nat) : Prop := 0 < c ∧ c ∣ L

instance (L c : Nat) : Decidable (Allowed L c) := by
  unfold Allowed
  infer_instance

def Digits (L n : Nat) : Prop := ∀ c ∈ Nat.digits 10 n, Allowed L c

instance (L n : Nat) : Decidable (Digits L n) := by
  unfold Digits Allowed
  infer_instance

def Predicate (n : Nat) : Prop := 0 < n ∧ ∀ d, d ∣ n → Digits n d

def Quotients (L n : Nat) : Prop :=
  ∀ i : Fin L, (i.val + 1) ∣ L → Digits L (n / (i.val + 1))

instance (L n : Nat) : Decidable (Quotients L n) := by
  unfold Quotients
  infer_instance

def repunit : Nat → Nat
  | 0 => 0
  | t + 1 => 10 * repunit t + 1

@[simp] theorem repunit_zero : repunit 0 = 0 := rfl
@[simp] theorem repunit_succ (t : Nat) : repunit (t+1) = 10*repunit t+1 := rfl

theorem long_division (P c d : Nat) (hd : 0 < d) :
    (10 * P + c) / d = 10 * (P / d) + (10 * (P % d) + c) / d := by
  calc
    (10 * P + c) / d = ((10 * (P % d) + c) + d * (10 * (P / d))) / d := by
      congr 1
      calc
        10 * P + c = 10 * (P % d + d * (P / d)) + c := by rw [Nat.mod_add_div]
        _ = _ := by ring
    _ = (10 * (P % d) + c) / d + 10 * (P / d) := Nat.add_mul_div_left _ _ hd
    _ = _ := Nat.add_comm _ _

theorem digits_append (L q c : Nat) (hq : 0 < q) (hc : c < 10) :
    Digits L (10*q+c) ↔ Allowed L c ∧ Digits L q := by
  unfold Digits
  rw [Nat.add_comm, Nat.digits_add 10 (by decide) c q hc (Or.inr (by omega))]
  simp

theorem digits_prefix (L n : Nat) (h : Digits L n) : Digits L (n/10) := by
  by_cases hn : n = 0
  · subst n
    simpa using h
  · unfold Digits at *
    rw [Nat.digits_eq_cons_digits_div (by decide) hn] at h
    exact (List.forall_mem_cons.mp h).2

theorem quotients_prefix (L n : Nat) (h : Quotients L n) : Quotients L (n/10) := by
  intro i hi
  have hh := digits_prefix L (n/(i.val+1)) (h i hi)
  simpa [Nat.div_div_eq_div_mul, Nat.mul_comm] using hh

theorem quotients_iff (L n : Nat) (hL : 0 < L) :
    Quotients L n ↔ ∀ d, d ∣ L → Digits L (n/d) := by
  constructor
  · intro h d hd
    have hd0 : 0 < d := Nat.pos_of_dvd_of_pos hd hL
    have hdL : d ≤ L := Nat.le_of_dvd hL hd
    have hh := h ⟨d-1, by omega⟩
    have hi : d - 1 + 1 = d := by omega
    simpa only [hi] using hh (by simpa only [hi] using hd)
  · intro h i hi
    exact h (i.val+1) hi

theorem small_digit_dvd (c : Nat) (hc0 : 0 < c) (hc10 : c < 10) : c ∣ 2520 := by
  interval_cases c <;> norm_num

theorem digits_gcd (n d : Nat) (h : Digits n d) : Digits (Nat.gcd n 2520) d := by
  intro c hc
  have hh := h c hc
  exact ⟨hh.1, Nat.dvd_gcd hh.2 (small_digit_dvd c hh.1 (Nat.digits_lt_base (by decide) hc))⟩

theorem predicate_quotients (n : Nat) (h : Predicate n) :
    Quotients (Nat.gcd n 2520) n := by
  intro i hi
  have hd : (i.val+1) ∣ n := dvd_trans hi (Nat.gcd_dvd_left n 2520)
  exact digits_gcd n _ (h.2 _ (Nat.div_dvd_of_dvd hd))

def Step (L r c : Nat) : Prop :=
  ∀ i : Fin L, (i.val+1) ∣ L → Allowed L ((10*(r % (i.val+1))+c)/(i.val+1))

instance (L r c : Nat) : Decidable (Step L r c) := by
  unfold Step Allowed
  infer_instance

theorem quotients_step (L P c : Nat) (hL : L ≤ 504) (hP : 1000 ≤ P)
    (hc : c < 10) (h : Quotients L (10*P+c)) : Step L (P%L) c := by
  intro i hi
  let d := i.val+1
  have hd : 0 < d := by dsimp [d]; omega
  have hdL : d ≤ L := by dsimp [d]; omega
  have hq : 0 < P/d := Nat.div_pos_iff.mpr ⟨hd, by omega⟩
  have hem : (10*(P%d)+c)/d < 10 := (Nat.div_lt_iff_lt_mul hd).2 (by
    have hh := Nat.mod_lt P hd
    omega)
  have hg : Digits L ((10*P+c)/d) := h i hi
  rw [long_division P c d hd] at hg
  have ha := (digits_append L (P/d) ((10*(P%d)+c)/d) hq hem).1 hg
  have heq : (P%L)%d = P%d := Nat.mod_mod_of_dvd P hi
  simpa only [d, heq] using ha.1

def fastDigits (L : Nat) : Nat → Nat → Bool
  | 0, n => n == 0
  | fuel+1, n => if n == 0 then true else
      decide (Allowed L (n%10)) && fastDigits L fuel (n/10)

theorem fastDigits_spec (L fuel n : Nat) (hn : n < 10^fuel) :
    fastDigits L fuel n = true ↔ Digits L n := by
  induction fuel generalizing n with
  | zero =>
    have : n = 0 := by simpa using hn
    subst n
    simp [fastDigits, Digits]
  | succ fuel ih =>
    by_cases hz : n = 0
    · subst n
      simp [fastDigits, Digits]
    · have hdiv : n/10 < 10^fuel := (Nat.div_lt_iff_lt_mul (by decide)).2 (by
        simpa [Nat.pow_succ, Nat.mul_comm] using hn)
      rw [fastDigits]
      simp only [beq_iff_eq, hz, ↓reduceIte, Bool.and_eq_true, decide_eq_true_eq]
      rw [ih _ hdiv]
      unfold Digits
      rw [Nat.digits_eq_cons_digits_div (by decide) hz]
      simp


end A209933

#print axioms A209933.long_division
#print axioms A209933.digits_append
#print axioms A209933.quotients_prefix
