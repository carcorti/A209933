module
public import A209933.Certificate
public import A209933.Arithmetic
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace A209933

theorem coefficient_bounds : ∀ m ∈ coefficients, 0 < m ∧ m ≤ 24 := by decide +kernel

theorem coefficient_divisors : ∀ m ∈ coefficients, ∀ d : Fin 25,
    d.val ∣ m → d.val ∈ coefficients := by decide +kernel

theorem coefficient_dvd (m d : Nat) (hm : m ∈ coefficients) (hd : d ∣ m) :
    d ∈ coefficients := by
  have hb := coefficient_bounds m hm
  exact coefficient_divisors m hm ⟨d, by have := Nat.le_of_dvd hb.1 hd; omega⟩ hd

theorem small_bounds : ∀ n ∈ coefficients ++ [15,48], 0 < n ∧ n ≤ 48 := by decide +kernel

theorem small_divisor_digits : ∀ n ∈ coefficients ++ [15,48], ∀ d : Fin 49,
    d.val ∣ n → Digits n d.val := by decide +kernel

theorem small_predicate (n : Nat) (hn : n ∈ coefficients ++ [15,48]) : Predicate n := by
  have hb := small_bounds n hn
  refine ⟨hb.1,fun d hd => ?_⟩
  exact small_divisor_digits n hn ⟨d,by have := Nat.le_of_dvd hb.1 hd; omega⟩ hd

theorem digits_repdigit (d t : Nat) (hd0 : 0 < d) (hd10 : d < 10) :
    Digits d (d*repunit t) := by
  induction t with
  | zero => simp [repunit,Digits]
  | succ t ih =>
    cases t with
    | zero =>
      simp only [repunit_succ,repunit_zero,Nat.mul_zero,Nat.zero_add,Nat.mul_one]
      unfold Digits
      rw [Nat.digits_of_lt 10 d (by omega) hd10]
      simpa [Allowed] using And.intro hd0 (dvd_refl d)
    | succ t =>
      have hp : 0 < d*repunit (t+1) := Nat.mul_pos hd0 (repunit_pos _ (by omega))
      have heq : d*repunit (t+1+1)=10*(d*repunit (t+1))+d := by rw [repunit_succ];ring
      rw [heq,digits_append d _ d hp hd10]
      exact ⟨⟨hd0,dvd_refl d⟩,ih⟩

theorem digits_twelve (t : Nat) (ht : 0 < t) :
    Digits 12 (12*repunit t) ∧ Digits 12 (12*repunit t+1) := by
  cases t with
  | zero => omega
  | succ t =>
    induction t with
    | zero => decide +kernel
    | succ t ih =>
      have hp : 0 < 12*repunit (t+1)+1 := by omega
      have h1 : 12*repunit (t+1+1)=10*(12*repunit (t+1)+1)+2 := by rw [repunit_succ];ring
      have h2 : 12*repunit (t+1+1)+1=10*(12*repunit (t+1)+1)+3 := by rw [repunit_succ];ring
      rw [h2,h1,digits_append 12 _ 2 hp (by decide),digits_append 12 _ 3 hp (by decide)]
      exact ⟨⟨by decide,(ih (by omega)).2⟩,⟨by decide,(ih (by omega)).2⟩⟩

theorem digits_twentyfour (t : Nat) (ht : 0 < t) :
    Digits 24 (24*repunit t) ∧ Digits 24 (24*repunit t+2) := by
  cases t with
  | zero => omega
  | succ t =>
    induction t with
    | zero => decide +kernel
    | succ t ih =>
      have hp : 0 < 24*repunit (t+1)+2 := by omega
      have h1 : 24*repunit (t+1+1)=10*(24*repunit (t+1)+2)+4 := by rw [repunit_succ];ring
      have h2 : 24*repunit (t+1+1)+2=10*(24*repunit (t+1)+2)+6 := by rw [repunit_succ];ring
      rw [h2,h1,digits_append 24 _ 4 hp (by decide),digits_append 24 _ 6 hp (by decide)]
      exact ⟨⟨by decide,(ih (by omega)).2⟩,⟨by decide,(ih (by omega)).2⟩⟩

theorem digits_family (m t : Nat) (hm : m ∈ coefficients) (ht : 0 < t) :
    Digits m (m*repunit t) := by
  by_cases hsmall : m < 10
  · exact digits_repdigit m t (coefficient_bounds m hm).1 hsmall
  · have hh : m=12 ∨ m=24 := by
      simp only [coefficients,List.mem_cons,List.not_mem_nil,or_false] at hm
      omega
    rcases hh with rfl | rfl
    · exact (digits_twelve t ht).1
    · exact (digits_twentyfour t ht).1

theorem prime_repunit_predicate (m t : Nat) (hm : m ∈ coefficients)
    (hp : Nat.Prime (repunit t)) : Predicate (m*repunit t) := by
  have ht : 0 < t := by
    by_contra h
    have hz : t=0 := by omega
    subst t
    exact hp.ne_zero rfl
  have hmpos := (coefficient_bounds m hm).1
  refine ⟨Nat.mul_pos hmpos hp.pos,fun d hd => ?_⟩
  by_cases hpd : repunit t ∣ d
  · obtain ⟨a,ha⟩ := hpd
    have had : a ∣ m := by
      rw [ha,Nat.mul_comm m] at hd
      exact (Nat.mul_dvd_mul_iff_left hp.pos).1 hd
    have haB := coefficient_dvd m a hm had
    rw [ha,Nat.mul_comm (repunit t)]
    exact digits_mono a (m*repunit t) _ (dvd_trans had (dvd_mul_right m _))
      (digits_family a t haB ht)
  · have hcop : Nat.Coprime d (repunit t) := (hp.coprime_iff_not_dvd.mpr hpd).symm
    have hdm : d ∣ m := hcop.dvd_of_dvd_mul_right hd
    have hdB := coefficient_dvd m d hm hdm
    have hs := small_predicate d (by simp [hdB])
    exact digits_mono d (m*repunit t) d hd (hs.2 d (dvd_refl d))

theorem exception_fifteen : ∀ L ∈ coefficients, ¬ Quotients L 15 := by decide +kernel

theorem exception_fortyeight : ∀ L ∈ coefficients, Quotients L 48 → L=24 := by decide +kernel

end A209933
#print axioms A209933.prime_repunit_predicate
