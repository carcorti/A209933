module
public import A209933.Model
@[expose] public section
namespace A209933

theorem repunit_pos (t : Nat) (ht : 0 < t) : 0 < repunit t := by
  cases t with
  | zero => omega
  | succ t => simp only [repunit_succ]; omega

theorem repunit_two_le (t : Nat) (ht : 2 ≤ t) : 11 ≤ repunit t := by
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le ht
  rw [Nat.add_comm 2 k, repunit_succ, repunit_succ]
  omega

theorem repunit_mod100 (t : Nat) (ht : 2 ≤ t) : repunit t % 100 = 11 := by
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le ht
  rw [Nat.add_comm 2 k, repunit_succ, repunit_succ]
  have hh : 10*(10*repunit k+1)+1=100*repunit k+11 := by ring
  rw [hh]
  omega

theorem repunit_odd (t : Nat) (ht : 0 < t) : repunit t % 2 = 1 := by
  cases t with
  | zero => omega
  | succ t => rw [repunit_succ]; omega

theorem repunit_index (t : Nat) (ht : 1 < repunit t) : 2 ≤ t := by
  cases t with
  | zero => simp at ht
  | succ t => cases t with
    | zero => norm_num [repunit] at ht
    | succ t => omega

theorem repunit_not_product (t a b : Nat) (ht : 2 ≤ t) (ha : 2 ≤ a) (hb : 2 ≤ b) :
    repunit a * repunit b ≠ repunit t := by
  intro h
  have hh := congrArg (fun n => n%100) h
  rw [Nat.mul_mod, repunit_mod100 a ha, repunit_mod100 b hb,
    repunit_mod100 t ht] at hh
  norm_num at hh

/-- Connect the recursive formal definition to the usual decimal repunit. -/
theorem repunit_power (t : Nat) : 9*repunit t+1=10^t := by
  induction t with
  | zero => norm_num [repunit]
  | succ t ih =>
    rw [repunit_succ,Nat.pow_succ,←ih]
    ring

theorem repunit_closed (t : Nat) : repunit t=(10^t-1)/9 := by
  rw [←repunit_power t]
  omega

theorem digits_mono (L N d : Nat) (hLN : L ∣ N) (h : Digits L d) : Digits N d := by
  intro c hc
  exact ⟨(h c hc).1, dvd_trans (h c hc).2 hLN⟩

end A209933
