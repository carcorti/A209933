module
public import A209933.Initial
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace A209933
set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem initial_shape_certificate : ∀ L ∈ classes, ∀ n ∈ initialWords L,
    (L ∈ coefficients ∧ ∃ t : Fin 5, ∃ e : Fin 3,
      e.val ∈ offsets L ∧ n = L*repunit t.val+e.val) ∨ Dead L (n%L) := by
  decide +kernel

set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem live_step_certificate : ∀ L ∈ coefficients, ∀ e ∈ offsets L, ∀ c : Fin 10,
    0 < c.val → Step L e c.val →
    ∃ e' : Fin 3, e'.val ∈ offsets L ∧ 10*e+c.val=L+e'.val := by
  decide +kernel

set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem dead_step_certificate : ∀ L ∈ [9,18,36], ∀ r : Fin 4, ∀ c : Fin 10,
    Dead L r.val → 0 < c.val → Step L r.val c.val →
    Dead L ((10*r.val+c.val)%L) := by
  decide +kernel

set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem small_certificate : ∀ L ∈ classes, ∀ n : Fin 1000,
    0 < n.val → L ∣ n.val → fastQ L n.val = true →
    n.val=15 ∨ n.val=48 ∨ (L ∈ coefficients ∧ ∃ t : Fin 4, n.val=L*repunit t.val) := by
  decide +kernel

set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem gcd_class_certificate : ∀ L : Fin 2521,
    0 < L.val → L.val ∣ 2520 → ¬10 ∣ L.val → L.val ∈ classes := by
  decide +kernel

end A209933
#print axioms A209933.initial_certificate
#print axioms A209933.live_step_certificate
#print axioms A209933.small_certificate
