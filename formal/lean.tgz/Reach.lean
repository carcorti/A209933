module
public import A209933.Finite
@[expose] public section
namespace A209933

theorem initial_invariant (L n : Nat) (hL : L ∈ classes) (hn : 1000 ≤ n)
    (hlt : n < 10000) (hQ : Quotients L n) : Invariant L n := by
  have hfast := fastQ_of_quotients L n hL hlt hQ
  have hshift : n-1000+1000=n := by omega
  have hstart := initial_certificate L hL ⟨n-1000, by omega⟩
  have hm : n ∈ initialWords L := by
    simpa only [hshift] using hstart (by simpa only [hshift] using hfast)
  rcases initial_shape_certificate L hL n hm with ⟨hB,t,e,he,heq⟩ | hd
  · exact Or.inl ⟨hB,t.val,e.val,he,heq⟩
  · exact Or.inr hd

theorem invariant_step (L P c : Nat) (hL : L ∈ classes) (hP : 1000 ≤ P)
    (hc0 : 0 < c) (hc10 : c < 10) (hQ : Quotients L (10*P+c))
    (hI : Invariant L P) : Invariant L (10*P+c) := by
  have hs := quotients_step L P c (classes_bounds L hL).2 hP hc10 hQ
  rcases hI with ⟨hB,t,e,he,hform⟩ | hd
  · have heL := offsets_bounds L hB e he
    have hr : P%L=e := by
      rw [hform]
      simp [Nat.add_mod, Nat.mod_eq_of_lt heL]
    have hse : Step L e c := by simpa only [hr] using hs
    rcases live_step_certificate L hB e he ⟨c,hc10⟩ hc0 hse with ⟨e',he',hnext⟩
    refine Or.inl ⟨hB,t+1,e'.val,he',?_⟩
    rw [hform]
    calc
      10*(L*repunit t+e)+c = L*(10*repunit t)+(10*e+c) := by ring
      _ = L*(10*repunit t)+(L+e'.val) := by rw [hnext]
      _ = L*repunit (t+1)+e'.val := by rw [repunit_succ]; ring
  · have hLs : L ∈ [9,18,36] := by
      rcases hd with ⟨rfl,_⟩ | ⟨rfl,_⟩ | ⟨rfl,_⟩ <;> simp
    have hr4 : P%L < 4 := by unfold Dead at hd; omega
    have hd' := dead_step_certificate L hLs ⟨P%L,hr4⟩ ⟨c,hc10⟩ hd hc0 hs
    apply Or.inr
    simpa [Nat.add_mod, Nat.mul_mod] using hd'

theorem quotients_invariant (L : Nat) (hL : L ∈ classes) :
    ∀ n, 1000 ≤ n → Quotients L n → Invariant L n := by
  intro n
  induction n using Nat.strong_induction_on with
  | ind n ih =>
    intro hn hQ
    by_cases hsmall : n < 10000
    · exact initial_invariant L n hL hn hsmall hQ
    · have hp : 1000 ≤ n/10 := by omega
      have hlt : n/10 < n := Nat.div_lt_self (by omega) (by decide)
      have hI := ih (n/10) hlt hp (quotients_prefix L n hQ)
      have hLpos := (classes_bounds L hL).1
      have hown : Digits L n := by
        simpa using hQ ⟨0,hLpos⟩ (one_dvd L)
      have hlast : Allowed L (n%10) := by
        have hz : n ≠ 0 := by omega
        unfold Digits at hown
        rw [Nat.digits_eq_cons_digits_div (by decide) hz] at hown
        exact (List.forall_mem_cons.mp hown).1
      have hnform : 10*(n/10)+n%10=n := Nat.div_add_mod n 10
      have hh := invariant_step L (n/10) (n%10) hL hp hlast.1
        (Nat.mod_lt n (by decide)) (by simpa only [hnform] using hQ) hI
      simpa only [hnform] using hh

theorem quotient_classification (L n : Nat) (hL : L ∈ classes) (hn : 0 < n)
    (hdvd : L ∣ n) (hQ : Quotients L n) :
    n=15 ∨ n=48 ∨ (L ∈ coefficients ∧ ∃ t, n=L*repunit t) := by
  by_cases hsmall : n < 1000
  · have hf := fastQ_of_quotients L n hL (by omega) hQ
    rcases small_certificate L hL ⟨n,hsmall⟩ hn hdvd hf with h15 | h48 | ⟨hB,t,ht⟩
    · exact Or.inl h15
    · exact Or.inr (Or.inl h48)
    · exact Or.inr (Or.inr ⟨hB,t.val,ht⟩)
  · have hmod : n%L=0 := Nat.mod_eq_zero_of_dvd hdvd
    rcases quotients_invariant L hL n (by omega) hQ with ⟨hB,t,e,he,hform⟩ | hd
    · have heL := offsets_bounds L hB e he
      have heq : n%L=e := by
        rw [hform]
        simp [Nat.add_mod, Nat.mod_eq_of_lt heL]
      have he0 : e=0 := by omega
      rw [he0,Nat.add_zero] at hform
      exact Or.inr (Or.inr ⟨hB,t,hform⟩)
    · unfold Dead at hd
      omega

theorem predicate_no_ten (n : Nat) (h : Predicate n) : ¬ 10 ∣ n := by
  intro hd
  have hh := h.2 n (dvd_refl n)
  have hz : n ≠ 0 := by have := h.1; omega
  have hmem : 0 ∈ Nat.digits 10 n := by
    rw [Nat.digits_eq_cons_digits_div (by decide) hz]
    simp [Nat.mod_eq_zero_of_dvd hd]
  have bad := (hh 0 hmem).1
  omega

theorem predicate_gcd_class (n : Nat) (h : Predicate n) : Nat.gcd n 2520 ∈ classes := by
  have hpos : 0 < Nat.gcd n 2520 := Nat.gcd_pos_of_pos_left 2520 h.1
  have hd := Nat.gcd_dvd_right n 2520
  have hle : Nat.gcd n 2520 ≤ 2520 := Nat.le_of_dvd (by decide) hd
  have hno : ¬ 10 ∣ Nat.gcd n 2520 := by
    intro hh
    exact predicate_no_ten n h (dvd_trans hh (Nat.gcd_dvd_left n 2520))
  exact gcd_class_certificate ⟨Nat.gcd n 2520,by omega⟩ hpos hd hno

theorem predicate_form (n : Nat) (h : Predicate n) :
    n=15 ∨ n=48 ∨ (Nat.gcd n 2520 ∈ coefficients ∧ ∃ t, n=Nat.gcd n 2520*repunit t) := by
  exact quotient_classification _ _ (predicate_gcd_class n h) h.1
    (Nat.gcd_dvd_left n 2520) (predicate_quotients n h)

end A209933
#print axioms A209933.quotient_classification
#print axioms A209933.predicate_form
