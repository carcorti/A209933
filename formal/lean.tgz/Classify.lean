module
public import A209933.Reach
public import A209933.Family
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace A209933

/- Every quotient used below is a divisor of the original parent.
   We do not assume that Predicate is inherited by arbitrary divisors. -/
theorem factor_quotients (n L u : Nat) (h : Predicate n) (hL : L=Nat.gcd n 2520)
    (hu : L*u ∣ n) : Quotients L (L*u) := by
  intro i hi
  have hid : (i.val+1) ∣ L*u := dvd_mul_of_dvd_left hi u
  have hd : (L*u/(i.val+1)) ∣ n := dvd_trans (Nat.div_dvd_of_dvd hid) hu
  have hg := digits_gcd n _ (h.2 _ hd)
  exact digits_mono (Nat.gcd n 2520) L _ (by rw [hL]) hg

theorem odd_divisor_repunit (t u : Nat) (ht : 0 < t) (hu : u ∣ repunit t) : u%2=1 := by
  have hodd := repunit_odd t ht
  by_contra hh
  have hu0 : u%2=0 := by have := Nat.mod_lt u (by decide : 0<2);omega
  obtain ⟨v,hv⟩ := hu
  rw [hv,Nat.mul_mod,hu0] at hodd
  norm_num at hodd

theorem factor_repunit (n L t u : Nat) (h : Predicate n)
    (hL : L=Nat.gcd n 2520) (hB : L ∈ coefficients)
    (hn : n=L*repunit t) (ht : 0<t) (hu : u ∣ repunit t) (hu1 : 1<u) :
    ∃ a, 2≤a ∧ u=repunit a := by
  have hLpos := (coefficient_bounds L hB).1
  have hLu : L*u ∣ n := by rw [hn];exact Nat.mul_dvd_mul_left L hu
  have hQ := factor_quotients n L u h hL hLu
  have hcls : L ∈ classes := by rw [hL];exact predicate_gcd_class n h
  rcases quotient_classification L (L*u) hcls (Nat.mul_pos hLpos (by omega))
    (dvd_mul_right L u) hQ with h15 | h48 | ⟨_,a,ha⟩
  · rw [h15] at hQ
    exact False.elim (exception_fifteen L hB hQ)
  · have h24 := exception_fortyeight L hB (by simpa only [h48] using hQ)
    have hu2 : u=2 := by rw [h24] at h48;omega
    have hodd := odd_divisor_repunit t u ht hu
    omega
  · have hua : u=repunit a := Nat.eq_of_mul_eq_mul_left hLpos ha
    exact ⟨a,repunit_index a (by omega),hua⟩

theorem necessary (n : Nat) (h : Predicate n) :
    n ∈ coefficients ∨ n=15 ∨ n=48 ∨
    ∃ m ∈ coefficients, ∃ t, Nat.Prime (repunit t) ∧ n=m*repunit t := by
  rcases predicate_form n h with h15 | h48 | ⟨hB,t,hn⟩
  · exact Or.inr (Or.inl h15)
  · exact Or.inr (Or.inr (Or.inl h48))
  · by_cases ht2 : 2≤t
    · have hprime : Nat.Prime (repunit t) := by
        by_contra hnp
        have hR := repunit_two_le t ht2
        obtain ⟨u,hu,hu2,hult⟩ := Nat.exists_dvd_of_not_prime2 (by omega) hnp
        obtain ⟨v,huv⟩ := hu
        have hv2 : 1<v := by
          by_contra hh
          have hv : v=0 ∨ v=1 := by omega
          rcases hv with hv0 | hv1
          · rw [hv0,Nat.mul_zero] at huv
            omega
          · rw [hv1,Nat.mul_one] at huv
            omega
        have hud : u ∣ repunit t := ⟨v,huv⟩
        have hvd : v ∣ repunit t := ⟨u,by simpa [Nat.mul_comm] using huv⟩
        obtain ⟨a,ha,hua⟩ := factor_repunit n (Nat.gcd n 2520) t u h rfl hB hn
          (by omega) hud (by omega)
        obtain ⟨b,hb,hvb⟩ := factor_repunit n (Nat.gcd n 2520) t v h rfl hB hn
          (by omega) hvd hv2
        exact repunit_not_product t a b ht2 ha hb (by rw [←hua,←hvb];exact huv.symm)
      exact Or.inr (Or.inr (Or.inr ⟨_,hB,t,hprime,hn⟩))
    · have ht : t=0 ∨ t=1 := by omega
      rcases ht with rfl | rfl
      · simp [repunit] at hn
        have := h.1
        omega
      · have hn' : n=Nat.gcd n 2520 := by simpa [repunit] using hn
        exact Or.inl (hn' ▸ hB)

/-- Full structural classification of the A209933 predicate, for every natural n.
    Nat.Prime is an ordinary predicate here, not an admitted catalog or axiom. -/
theorem classification (n : Nat) :
    Predicate n ↔ n ∈ coefficients ∨ n=15 ∨ n=48 ∨
      ∃ m ∈ coefficients, ∃ t, Nat.Prime (repunit t) ∧ n=m*repunit t := by
  constructor
  · exact necessary n
  · intro h
    rcases h with hB | rfl | rfl | ⟨m,hm,t,hp,rfl⟩
    · exact small_predicate n (by simp [hB])
    · exact small_predicate 15 (by simp)
    · exact small_predicate 48 (by simp)
    · exact prime_repunit_predicate m t hm hp

end A209933
#print axioms A209933.necessary
#print axioms A209933.classification
