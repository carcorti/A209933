module
public import A209933.Classify
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace A209933

/-- The defining property of A182183: every divisor satisfies A209933. -/
def DivisorClosed (n : Nat) : Prop := ∀ d, d ∣ n → Predicate d

theorem coefficient_divisor_closed (m : Nat) (hm : m ∈ coefficients) :
    DivisorClosed m := by
  intro d hd
  exact small_predicate d (by simp [coefficient_dvd m d hm hd])

theorem fifteen_divisor_closed : DivisorClosed 15 := by
  intro d hd
  have hle : d ≤ 15 := Nat.le_of_dvd (by decide) hd
  have hm : d ∈ coefficients ++ [15,48] := by
    interval_cases d <;> norm_num [coefficients] at *
  exact small_predicate d hm

theorem not_predicate_sixteen : ¬ Predicate 16 := by
  intro h
  have h6 : Allowed 16 6 := (h.2 16 (dvd_refl 16)) 6 (by decide)
  norm_num [Allowed] at h6

theorem not_divisor_closed_fortyeight : ¬ DivisorClosed 48 := by
  intro h
  exact not_predicate_sixteen (h 16 (by decide))

theorem prime_repunit_divisor_closed (m t : Nat) (hm : m ∈ coefficients)
    (hp : Nat.Prime (repunit t)) : DivisorClosed (m * repunit t) := by
  intro d hd
  by_cases hpd : repunit t ∣ d
  · obtain ⟨a, ha⟩ := hpd
    have had : a ∣ m := by
      rw [ha, Nat.mul_comm m] at hd
      exact (Nat.mul_dvd_mul_iff_left hp.pos).1 hd
    have haB := coefficient_dvd m a hm had
    rw [ha, Nat.mul_comm (repunit t)]
    exact prime_repunit_predicate a t haB hp
  · have hcop : Nat.Coprime d (repunit t) := (hp.coprime_iff_not_dvd.mpr hpd).symm
    have hdm : d ∣ m := hcop.dvd_of_dvd_mul_right hd
    exact small_predicate d (by simp [coefficient_dvd m d hm hdm])

/-- Exact all-natural set relation A182183 = A209933 minus the value 48. -/
theorem divisor_closed_iff (n : Nat) :
    DivisorClosed n ↔ Predicate n ∧ n ≠ 48 := by
  constructor
  · intro h
    refine ⟨h n (dvd_refl n), ?_⟩
    intro hn
    subst n
    exact not_divisor_closed_fortyeight h
  · rintro ⟨h, hn⟩
    rcases (classification n).1 h with hm | h15 | h48 | ⟨m, hm, t, hp, heq⟩
    · exact coefficient_divisor_closed n hm
    · simpa only [h15] using fifteen_divisor_closed
    · exact False.elim (hn h48)
    · rw [heq]
      exact prime_repunit_divisor_closed m t hm hp

end A209933
#print axioms A209933.divisor_closed_iff
