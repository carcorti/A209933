module
public import A209933.Certificate
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace A209933

private theorem init_1 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 1 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 1 := by decide +kernel
#check init_1

private theorem init_2 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 2 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 2 := by decide +kernel
#check init_2

private theorem init_3 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 3 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 3 := by decide +kernel
#check init_3

private theorem init_4 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 4 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 4 := by decide +kernel
#check init_4

private theorem init_5 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 5 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 5 := by decide +kernel
#check init_5

private theorem init_6 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 6 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 6 := by decide +kernel
#check init_6

private theorem init_7 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 7 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 7 := by decide +kernel
#check init_7

private theorem init_8 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 8 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 8 := by decide +kernel
#check init_8

private theorem init_9 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 9 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 9 := by decide +kernel
#check init_9

private theorem init_12 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 12 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 12 := by decide +kernel
#check init_12

private theorem init_14 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 14 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 14 := by decide +kernel
#check init_14

private theorem init_15 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 15 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 15 := by decide +kernel
#check init_15

private theorem init_18 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 18 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 18 := by decide +kernel
#check init_18

private theorem init_21 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 21 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 21 := by decide +kernel
#check init_21

private theorem init_24 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 24 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 24 := by decide +kernel
#check init_24

private theorem init_28 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 28 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 28 := by decide +kernel
#check init_28

private theorem init_35 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 35 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 35 := by decide +kernel
#check init_35

private theorem init_36 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 36 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 36 := by decide +kernel
#check init_36

private theorem init_42 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 42 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 42 := by decide +kernel
#check init_42

private theorem init_45 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 45 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 45 := by decide +kernel
#check init_45

private theorem init_56 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 56 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 56 := by decide +kernel
#check init_56

private theorem init_63 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 63 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 63 := by decide +kernel
#check init_63

private theorem init_72 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 72 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 72 := by decide +kernel
#check init_72

private theorem init_84 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 84 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 84 := by decide +kernel
#check init_84

private theorem init_105 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 105 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 105 := by decide +kernel
#check init_105

private theorem init_126 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 126 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 126 := by decide +kernel
#check init_126

private theorem init_168 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 168 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 168 := by decide +kernel
#check init_168

private theorem init_252 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 252 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 252 := by decide +kernel
#check init_252

private theorem init_315 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 315 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 315 := by decide +kernel
#check init_315

private theorem init_504 : ∀ a : Fin 9, ∀ b c d : Fin 10,
    fastQ 504 ((a.val+1)*1000+b.val*100+c.val*10+d.val) = true →
    (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords 504 := by decide +kernel
#check init_504

theorem initial_certificate : ∀ L ∈ classes, ∀ P : Fin 9000,
    fastQ L (P.val+1000) = true → P.val+1000 ∈ initialWords L := by
  intro L hL P hQ
  let n := P.val+1000
  have hn : 1000 ≤ n ∧ n < 10000 := by dsimp [n]; omega
  let a : Fin 9 := ⟨n/1000-1,by omega⟩
  let b : Fin 10 := ⟨(n/100)%10,Nat.mod_lt _ (by decide)⟩
  let c : Fin 10 := ⟨(n/10)%10,Nat.mod_lt _ (by decide)⟩
  let d : Fin 10 := ⟨n%10,Nat.mod_lt _ (by decide)⟩
  have heq : (a.val+1)*1000+b.val*100+c.val*10+d.val=n := by
    dsimp [a,b,c,d]; omega
  have hQ' : fastQ L ((a.val+1)*1000+b.val*100+c.val*10+d.val)=true := by
    simpa only [heq] using hQ
  have goal : (a.val+1)*1000+b.val*100+c.val*10+d.val ∈ initialWords L := by
    simp only [classes,List.mem_cons,List.not_mem_nil,or_false] at hL
    rcases hL with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact init_1 a b c d hQ'
    · exact init_2 a b c d hQ'
    · exact init_3 a b c d hQ'
    · exact init_4 a b c d hQ'
    · exact init_5 a b c d hQ'
    · exact init_6 a b c d hQ'
    · exact init_7 a b c d hQ'
    · exact init_8 a b c d hQ'
    · exact init_9 a b c d hQ'
    · exact init_12 a b c d hQ'
    · exact init_14 a b c d hQ'
    · exact init_15 a b c d hQ'
    · exact init_18 a b c d hQ'
    · exact init_21 a b c d hQ'
    · exact init_24 a b c d hQ'
    · exact init_28 a b c d hQ'
    · exact init_35 a b c d hQ'
    · exact init_36 a b c d hQ'
    · exact init_42 a b c d hQ'
    · exact init_45 a b c d hQ'
    · exact init_56 a b c d hQ'
    · exact init_63 a b c d hQ'
    · exact init_72 a b c d hQ'
    · exact init_84 a b c d hQ'
    · exact init_105 a b c d hQ'
    · exact init_126 a b c d hQ'
    · exact init_168 a b c d hQ'
    · exact init_252 a b c d hQ'
    · exact init_315 a b c d hQ'
    · exact init_504 a b c d hQ'
  simpa only [heq] using goal
end A209933
#print axioms A209933.initial_certificate
